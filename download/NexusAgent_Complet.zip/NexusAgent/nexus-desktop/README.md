# NEXUS Agent — Desktop Application

Application desktop NEXUS Agent construite avec Electron.

## Installation One-Click

### Windows
1. Téléchargez `NEXUS-Agent-Setup-1.0.0.exe`
2. Double-cliquez pour installer
3. L'application démarre automatiquement

### macOS
1. Téléchargez `NEXUS-Agent-1.0.0.dmg`
2. Glissez dans Applications
3. Lancez NEXUS Agent

### Linux
1. Téléchargez `NEXUS-Agent-1.0.0.AppImage`
2. `chmod +x NEXUS-Agent-1.0.0.AppImage`
3. `./NEXUS-Agent-1.0.0.AppImage`

## Développement

```bash
npm install
npm start
```

## Build

```bash
npm run dist:win     # Windows
npm run dist:mac     # macOS
npm run dist:linux   # Linux
```

## Prérequis

L'installateur installe automatiquement :
- Python 3.11+
- Node.js 20+
- Toutes les dépendances Python (via pip)
- Toutes les dépendances Node.js (via npm)
