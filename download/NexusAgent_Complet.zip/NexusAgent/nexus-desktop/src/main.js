// ═══════════════════════════════════════════════════════════════
// NEXUS Desktop — Electron Main Process
// ═══════════════════════════════════════════════════════════════

const { app, BrowserWindow, Menu, Tray, shell, dialog } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow = null;
let tray = null;
let backendProcess = null;
let frontendProcess = null;

const isDev = !app.isPackaged;
const resourcesPath = isDev ? path.join(__dirname, '..') : process.resourcesPath;

// ── Backend Management ──────────────────────────────────────

function startBackend() {
  const backendDir = isDev
    ? path.join(resourcesPath)
    : path.join(resourcesPath, 'backend');

  const pythonCmd = process.platform === 'win32' ? 'python' : 'python3';
  const entryPoint = isDev
    ? path.join(backendDir, 'run_nexus.py')
    : path.join(backendDir, 'run_nexus.py');

  backendProcess = spawn(pythonCmd, [entryPoint, 'serve', '--host', '127.0.0.1', '--port', '8081'], {
    cwd: backendDir,
    env: { ...process.env, NEXUS_ENV: 'production', NEXUS_PORT: '8081' },
    stdio: 'pipe',
  });

  backendProcess.stdout?.on('data', (data) => {
    console.log(`[Backend] ${data}`);
  });

  backendProcess.stderr?.on('data', (data) => {
    console.error(`[Backend] ${data}`);
  });

  backendProcess.on('close', (code) => {
    console.log(`Backend exited with code ${code}`);
  });
}

function stopBackend() {
  if (backendProcess) {
    backendProcess.kill();
    backendProcess = null;
  }
}

// ── Window Creation ─────────────────────────────────────────

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: 'NEXUS Agent',
    backgroundColor: '#0c0f1a',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webviewTag: false,
    },
    icon: path.join(__dirname, '..', 'assets', 'icon.png'),
    show: false,
  });

  // Load the web frontend
  const frontendUrl = 'http://127.0.0.1:3000';
  mainWindow.loadURL(frontendUrl);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Open external links in system browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ── App Lifecycle ───────────────────────────────────────────

app.whenReady().then(() => {
  // Start backend
  startBackend();

  // Wait a bit for backend to start, then create window
  setTimeout(() => {
    createWindow();
  }, 2000);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  stopBackend();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  stopBackend();
});

// Prevent multiple instances
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}
